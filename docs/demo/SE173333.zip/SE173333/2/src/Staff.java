public class Staff {
    private String name;
    private double baseSalary;

    public Staff() {
        this.name = "";
        this.baseSalary = 0;
    }

    public Staff(String name, double baseSalary) {
        this.name = name;
        this.baseSalary = baseSalary;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public double getBaseSalary() { return baseSalary; }
    public void setBaseSalary(double baseSalary) { this.baseSalary = baseSalary; }

    public double getAllowance() {
        if (baseSalary >= 2000) {
            return baseSalary * 0.20;
        }
        return baseSalary * 0.10;
    }
}
