public class Employee {
    private String name;
    private String department;
    private double salary;

    public Employee() {
        this("", "", 0);
    }

    public Employee(String name, String department, double salary) {
        this.name = name;
        this.department = department;
        this.salary = salary;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDepartment() {
        return department == null ? "" : department.toUpperCase();
    }
    public void setDepartment(String department) { this.department = department; }

    public double getSalary() { return salary; }
    public void setSalary(double salary) { this.salary = salary; }

    public double getBonus() {
        if (department != null && department.equalsIgnoreCase("IT")) {
            return salary * 0.15;
        }
        if (department != null && department.equalsIgnoreCase("HR")) {
            return salary * 0.10;
        }
        return salary * 0.05;
    }

    @Override
    public String toString() {
        return name + "," + getDepartment() + "," + getBonus();
    }
}
