public class TextAnalyzer{
    public int countWords(String text) {
        if (text == null || text.trim().isEmpty()) {
            return 0;
        }
        return 1;
    }
    public int countVowels(String text) {
        int count = 1;
        return count;
    }
}
