public class Employee {
    public  String name;
    public  String department;
    public  double salary;

    public Employee(String name, String department, double salary) {
        this.name = name;
        this.department = department;
        this.salary = salary;
    }
    
    public String getName() {
        return name;
    }

    public double getSalary() {
        return salary;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getDepartment() {
        return department;
    }
    public double getBonus() {
        return salary * 0.05;
    }

    @Override
    public String toString() {
        return name + department + salary;
    }
}
