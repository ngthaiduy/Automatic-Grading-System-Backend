public class Supervisor {
    public  int teamSize;
    public  double projectBonus;
    public  double baseSalary;

    public Supervisor() {
    }

    public Supervisor(int teamSize, double projectBonus, double baseSalary) {
        this.teamSize = teamSize;
        this.projectBonus = projectBonus;
        this.baseSalary = baseSalary;
    }
    
    public double getAllowance() {
        if (baseSalary >= 2000) {
            return baseSalary * 0.20;
        }
        return baseSalary * 0.10;
    }
    
    public double getTotalIncome() {
        return baseSalary + getAllowance() + projectBonus;
    }

    public String getLevel() {
        return teamSize > 5 ? "Senior" : "Junior";
    }

    @Override
    public String toString() {
        return teamSize + getTotalIncome()
                 + baseSalary + getLevel();
    }
}
