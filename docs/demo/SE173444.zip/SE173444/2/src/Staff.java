public class Staff {
    public  String name;
    public  double baseSalary;

    public Staff() {
    }

    public Staff(String name, double baseSalary) {
        this.name = name;
        this.baseSalary = baseSalary;
    }

    public double getAllowance() {
        if (baseSalary >= 2000) {
            return baseSalary * 0.20;
        }
        return baseSalary * 0.10;
    }
}
