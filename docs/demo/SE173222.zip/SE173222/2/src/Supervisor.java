
public class Supervisor extends Staff {

    private int teamSize;
    private double projectBonus;

    public Supervisor() {
        super();
    }

    public Supervisor(String name, double baseSalary, int teamSize, double projectBonus) {
        super(name, baseSalary);
        this.teamSize = teamSize;
        this.projectBonus = projectBonus;
    }

    public double getProjectBonus() {
        return projectBonus;
    }

    public void setProjectBonus(double projectBonus) {
        this.projectBonus = projectBonus;
    }

    public double getTotalIncome() {
        return getBaseSalary() + getAllowance() + projectBonus;
    }

    public String getLevel() {
        return teamSize >= 5 ? "Senior" : "Junior";
    }

    public String toString() {
        return teamSize + "-" + String.format("%.2f", getTotalIncome()) + "-" + String.format("%.2f", getBaseSalary()) + "-" + getLevel();
    }
}
