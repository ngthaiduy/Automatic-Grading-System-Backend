
public class Staff {

    public  String name;
    public  double baseSalary;

    public Staff() {
        this("", 0);
    }

    public Staff(String name, double baseSalary) {
        this.name = name;
        this.baseSalary = baseSalary;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getBaseSalary() {
        return baseSalary;
    }


    public double getAllowance() {
        return baseSalary >= 2000 ? baseSalary * 0.20 : baseSalary * 0.10;
    }
}
